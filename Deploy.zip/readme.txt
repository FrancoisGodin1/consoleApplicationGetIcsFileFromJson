please rename : 

Newtonsoft.Json.txt to Newtonsoft.Json.dll 

AND

ConvertJsonEventsOfCalendarToIcsFile.txt to ConvertJsonEventsOfCalendarToIcsFile.exe

after you will run ConvertJsonEventsOfCalendarToIcsFile.exe, thanks you.